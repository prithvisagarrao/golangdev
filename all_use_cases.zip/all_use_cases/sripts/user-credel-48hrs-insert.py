#!/usr/bin/env python
from elasticsearch import Elasticsearch
from datetime import datetime, timedelta

import psycopg2


#es = Elasticsearch([{'host': '10.200.147.78', 'port': 9200},{'host': '10.200.147.79', 'port': 9200},{'host': '10.200.147.80', 'port': 9200}])
es = Elasticsearch([{'host': '172.18.0.3', 'port': 9200}])

TODAYDATE = datetime.today().strftime('%Y.%m.%d')
YDATE = datetime.strftime(datetime.now() - timedelta(1), '%Y.%m.%d')

TODAYALERTS = "siem-alerts-3.x-" + TODAYDATE
YESTERDAYALERTS  ="siem-alerts-3.x-" + YDATE

testalert = "siem-alerts-3.x-2019.03.27"

#delresponse = es.search(index=TODAYALERTS,body={"from":0,"size":10000,"query":{"bool":{"must":[{"match":{"rule.id":"20012"}},{"match":{"data.EventChannel.System.EventID":"4726"}},{"range":{"@timestamp":{"gte":"now-10m/m","lte":"now/m"}}},{"query_string":{"query":"!(data.EventChannel.EventData.TargetUserName:*$)","analyze_wildcard":True,"default_field":"*"}}]}}},_source=["data.EventChannel.System.SystemTime","data.EventChannel.EventData.TargetUserName"])
#
#print(delresponse)
#

runtime = None
connection = None
postgres_select_runtime_query = "select script_timestamp from run_log where script_type='cre_del' order by script_timestamp desc limit 1 "
try:
    connection = psycopg2.connect(user="postgres",
                                 password="postgres",
                                 host="localhost",
                                 port="5432",
                                 database="wazuhdb")

    cursor = connection.cursor()

    try:
        cursor.execute(postgres_select_runtime_query)

        runtime_records = cursor.fetchall()
        for x in runtime_records:
            runtime = x[0]
            #print(runtime)

    except psycopg2.IntegrityError as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()
    cursor.close()
except Exception as e:
    print('ERROR', e)

finally:
    if connection is not None:
        connection.close()


if runtime:
    addedtodayresponse = es.search(body={"from": 0, "size": 10000, "query": {"bool": {"should": [{"bool": {
        "must": [{"match": {"rule.id": "20010"}}, {"match": {"data.EventChannel.System.EventID": "4720"}},
                 {"range": {"@timestamp": {"gte": "now-2d/d", "lte": "now/d"}}}, {
                     "query_string": {"query": "!(data.EventChannel.EventData.TargetUserName:*$)",
                                      "analyze_wildcard": True, "default_field": "*"}}]}}, {"bool": {
        "must": [{"match": {"rule.id": "20012"}}, {"match": {"data.EventChannel.System.EventID": "4726"}},
                 {"range": {"@timestamp": {"gte": runtime, "lte": "now"}}}, {
                     "query_string": {"query": "!(data.EventChannel.EventData.TargetUserName:*$)",
                                      "analyze_wildcard": True, "default_field": "*"}}]}}]}}},
                                   _source=["data.EventChannel.System.SystemTime",
                                            "data.EventChannel.EventData.TargetUserName", "rule.id"])
else:
    addedtodayresponse = es.search(body={"from": 0, "size": 10000, "query": {"bool": {"should": [{"bool": {
        "must": [{"match": {"rule.id": "20010"}}, {"match": {"data.EventChannel.System.EventID": "4720"}},
                 {"range": {"@timestamp": {"gte": "now-2d/d", "lte": "now/d"}}}, {
                     "query_string": {"query": "!(data.EventChannel.EventData.TargetUserName:*$)",
                                      "analyze_wildcard": True, "default_field": "*"}}]}}, {"bool": {
        "must": [{"match": {"rule.id": "20012"}}, {"match": {"data.EventChannel.System.EventID": "4726"}},
                 {"range": {"@timestamp": {"gte": "now-2d/d", "lte": "now/d"}}}, {
                     "query_string": {"query": "!(data.EventChannel.EventData.TargetUserName:*$)",
                                      "analyze_wildcard": True, "default_field": "*"}}]}}]}}},
                                   _source=["data.EventChannel.System.SystemTime",
                                            "data.EventChannel.EventData.TargetUserName", "rule.id"])

#print(addedtodayresponse)

added_dict = {}

if addedtodayresponse:
    added_hits = (addedtodayresponse.get('hits',{}).get('hits'))

for x in added_hits:
    timestamp = x.get('_source', {}).get('data', {}).get('EventChannel', {}).get(
        'System', {}).get('SystemTime')
    target_username = x.get('_source', {}).get('data', {}).get('EventChannel', {}).get('EventData', {}).get(
        'TargetUserName')
    rule_id = x.get('_source', {}).get('rule', {}).get('id' )
    concat_key= target_username + "~~~" + timestamp
    #print(concat_key)
    added_dict[concat_key] = rule_id

added_list = []
for key,val in added_dict.items():
    name, added_time = key.split("~~~")
    if val == "20010":
        added_tuple = (name,'create', added_time, key)
    else:
        added_tuple = (name,'delete',added_time,key)
    added_list.append(added_tuple)

postgres_insert_query = """ INSERT INTO user_creation (target_user_name, action, creation_time, concat_key) VALUES (%s,%s,%s, %s) ON CONFLICT(concat_key) DO NOTHING"""

# insert into run_log as query ran successfully
#postgres_runlog_insert_query = """ INSERT INTO run_log (script_type, script_timestamp) VALUES ('cre_del',now())"""

try:

    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")

    cursor = connection.cursor()

    try:
        if added_list is not None:
            cursor.executemany(postgres_insert_query, added_list)
        #cursor.execute(postgres_runlog_insert_query)

    except psycopg2.Error as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()

    cursor.close()
except Exception as e:
    print ('ERROR', e)
finally:
    if connection is not None:
        connection.close()



