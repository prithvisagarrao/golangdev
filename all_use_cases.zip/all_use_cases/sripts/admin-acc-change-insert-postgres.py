#!/usr/bin/env python
import json
import sys
from elasticsearch import Elasticsearch
from datetime import datetime, timedelta

import psycopg2

es = Elasticsearch([{'host': '172.18.0.3', 'port': 9200}])

# TODAYDATE = datetime.today().strftime('%Y.%m.%d')
# YDATE = datetime.strftime(datetime.now() - timedelta(1), '%Y.%m.%d')
#
# TODAYALERTS = "wazuh-alerts-3.x-" + TODAYDATE
# YESTERDAYALERTS  ="wazuh-alerts-3.x-" + YDATE
#
# testalert = "wazuh-alerts-3.x-2019.03.27"

connection = None
runtime = None
postgres_select_runtime_query = "select script_timestamp from run_log where script_type='admin_change' order by script_timestamp desc limit 1 "
try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")

    cursor = connection.cursor()

    try:
        cursor.execute(postgres_select_runtime_query)

        runtime_records = cursor.fetchall()
        for x in runtime_records:
            runtime = x[0]
            print(runtime)

    except psycopg2.IntegrityError as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()
    cursor.close()
except Exception as e:
    print('ERROR', e)

finally:
    if connection is not None:
        connection.close()



if runtime:
    addedtodayresponse = es.search(body={"from": 0, "size": 10000, "query": {"bool": {
        "must": [{"match_all": {}}, {"match_phrase": {"data.EventChannel.System.EventID": {"query": "4738"}}},
                 {"match_phrase": {"rule.id": {"query": "20011"}}},
                 {"range": {"@timestamp": {"gte": runtime, "lte": "now"}}}]}}})
else:
    addedtodayresponse = es.search(body={"from": 0, "size": 10000, "query": {"bool": {
        "must": [{"match_all": {}}, {"match_phrase": {"data.EventChannel.System.EventID": {"query": "4738"}}},
                 {"match_phrase": {"rule.id": {"query": "20011"}}},
                 {"range": {"@timestamp": {"gte": "now-1d/d", "lte": "now/d"}}}]}}})
#,{"range":{"@timestamp":{"gte":runtime,"lte":"now"}}}
#print(addedtodayresponse)

data_list = []

added_hits = (addedtodayresponse.get('hits',{}).get('hits',{}))

for x in added_hits:
    data = x.get('_source', {}).get('data')
    data_list.append(data)

print(data_list)

data_dict = {}

for d in data_list:
    timestamp = d.get('EventChannel', {}).get('System', {}).get('SystemTime')
    target_username = d.get('EventChannel', {}).get('EventData', {}).get('TargetUserName')
    concat_key_val = target_username + "~~~" + timestamp
    concat_key_val = concat_key_val.strip()
    #print(concat_key)
    data_dict[concat_key_val] = d
    print(data_dict)

insert_values = []


for key,val in data_dict.items():
    name, event_time = key.split("~~~")
    insert_tuple = (event_time,json.dumps(val),key)
    insert_values.append(insert_tuple)

#print(insert_values)
#print(concat_key_val)
postgres_insert_query = """ INSERT INTO admin_acc_change (event_timestamp,data,concat_key) VALUES (%s,%s,%s) ON CONFLICT(concat_key) DO NOTHING """

# insert into run_log as query ran successfully
#postgres_runlog_insert_query = """ INSERT INTO run_log (script_type, script_timestamp) VALUES ('admin_change','now()')"""

try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")

    cursor = connection.cursor()

    try:
        if insert_values is not None:
            cursor.executemany(postgres_insert_query, insert_values)
        #cursor.execute(postgres_runlog_insert_query)

    except psycopg2.Error as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()

    cursor.close()

except Exception as e:
    print ('ERROR', e)

finally:
    if connection is not None:
        connection.close()


