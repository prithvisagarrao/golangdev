#!/usr/bin/env python
# import json
import os, stat
# import socket
# from elasticsearch import Elasticsearch
# from datetime import datetime, timedelta
import subprocess

import psycopg2

connection = None
usernames = []
concat_keys = []
try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")
    cursor = connection.cursor()

    postgres_select_username_query = """select username, concat_key, alert_status from (
    select data -> 'EventChannel' -> 'EventData' ->> 'TargetUserName' AS username, concat_key, alert_status from login_failure_4768) t 
    where t.username in (
    select distinct admin_username from admin_users_master)
    and
    alert_status is null;"""

    cursor.execute(postgres_select_username_query)
    #to be deleted
    #print("Number of rows:", cursor.rowcount)

    row = cursor.fetchone()

    while row is not None:
        #print(row[0])
        usernames.append(row[0])
        concat_keys.append(row[1])
        row = cursor.fetchone()

    cursor.close()

except (Exception, psycopg2.Error) as e:
    print("Error while fetching data from postgresql:",e)

finally:
    if connection is not None:
        connection.close()



# if os.path.exists("/var/ossec/queue/ossec/queue"):
#     client = socket.socket( socket.AF_UNIX, socket.SOCK_DGRAM)
#
#     client.connect("/var/ossec/queue/ossec/queue")
#
#     for name in usernames:
#         s = "AdminAccChanged: " + name
#         client.send(s.encode())
#
#     client.close()
# else:
#     print("Couldn't connect")

usernames_set = set(usernames)
concat_keys_tuple = tuple(concat_keys)

if usernames_set:
    for name in (usernames_set):

        path = "/var/ossec/queue/ossec/queue"
        mode = os.stat(path).st_mode
        isSocket = stat.S_ISSOCK(mode)
        print(isSocket)
        e = 'echo 1:admin-login-fail-select.py:AdminLoginFail {} | nc -Uu /var/ossec/queue/ossec/queue'.format(name)
        print(e)
        subprocess.call(e,shell=True)

print("Done")

postgres_insert_change_status_query = """update login_failure_4768 SET alert_status = 'generated'
where concat_key in %s"""

try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")
    cursor = connection.cursor()

    try:
        if concat_keys_tuple:
            cursor.execute(postgres_insert_change_status_query, (concat_keys_tuple,))

    except psycopg2.Error as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()

    cursor.close()

except Exception as e:
    print ('ERROR', e)

finally:
    if connection is not None:
        connection.close()

postgres_runlog_insert_query = """ INSERT INTO run_log (script_type, script_timestamp) VALUES ('brute_force','now()')"""

#postgres_delete_acc_change_query = """TRUNCATE TABLE admin_acc_change"""

try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")

    cursor = connection.cursor()

    try:
        cursor.execute(postgres_runlog_insert_query)
        #cursor.execute(postgres_delete_acc_change_query)

    except psycopg2.Error as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()

    cursor.close()

except Exception as e:
    print ('ERROR', e)

finally:
    if connection is not None:
        connection.close()



