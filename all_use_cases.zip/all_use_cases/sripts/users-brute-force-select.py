#!/usr/bin/env python
# import json
# import os
# import socket
from elasticsearch import Elasticsearch
from datetime import datetime, timedelta
import subprocess

import psycopg2

es = Elasticsearch([{'host': '172.18.0.3', 'port': 9200}])

TODAYDATE = datetime.today().strftime('%Y.%m.%d')
YDATE = datetime.strftime(datetime.now() - timedelta(1), '%Y.%m.%d')

TODAYALERTS = "siem-alerts-3.x-" + TODAYDATE
YESTERDAYALERTS  = "siem-alerts-3.x-" + YDATE

testalert = "siem-alerts-3.x-2019.03.27"

#delresponse = es.search(index=TODAYALERTS,body={"from":0,"size":10000,"query":{"bool":{"must":[{"match":{"rule.id":"20012"}},{"match":{"data.EventChannel.System.EventID":"4726"}},{"range":{"@timestamp":{"gte":"now-10m/m","lte":"now/m"}}},{"query_string":{"query":"!(data.EventChannel.EventData.TargetUserName:*$)","analyze_wildcard":True,"default_field":"*"}}]}}},_source=["data.EventChannel.System.SystemTime","data.EventChannel.EventData.TargetUserName"])
#
#print(delresponse)
#
connection = None
usernames = []
event_time = []
try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")
    cursor = connection.cursor()

    postgres_select_username_query = """select
    data -> 'EventChannel' -> 'EventData' ->> 'TargetUserName' as user, count(*) 
    from login_failure_4768 
    group by 
    data -> 'EventChannel' -> 'EventData' ->> 'TargetUserName' 
    having count(*) > 3;"""

    cursor.execute(postgres_select_username_query)
    #to be deleted
    print("Number of rows:", cursor.rowcount)

    row = cursor.fetchone()

    while row is not None:
        #print(row[0])
        usernames.append(row[0])
        #event_time.append(row[1])
        row = cursor.fetchone()

    cursor.close()

except (Exception, psycopg2.Error) as e:
    print("Error while fetching data from postgresql:",e)

finally:
    if connection is not None:
        connection.close()


# if os.path.exists("/var/ossec/queue/ossec/queue"):
#     client = socket.socket( socket.AF_UNIX, socket.SOCK_DGRAM)
#
#     client.connect("/var/ossec/queue/ossec/queue")
#
#     for name in usernames:
#         s = "AdminAccChanged: " + name
#         client.send(s.encode())
#
#     client.close()
# else:
#     print("Couldn't connect")

usernames_set= set(usernames)
for name in (usernames_set):

    e = 'echo 1:postgres-get-admin-acc.py:BruteForceUsers {} | nc -Uu /var/ossec/queue/ossec/queue'.format(name)
    print(e)
    subprocess.call(e,shell=True)

print("Done")



postgres_runlog_insert_query = """ INSERT INTO run_log (script_type, script_timestamp) VALUES ('brute_force','now()')"""

#postgres_delete_acc_change_query = """TRUNCATE TABLE admin_acc_change"""

try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")

    cursor = connection.cursor()

    try:
        cursor.execute(postgres_runlog_insert_query)
        #cursor.execute(postgres_delete_acc_change_query)

    except psycopg2.Error as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()

    cursor.close()

except Exception as e:
    print ('ERROR', e)

finally:
    if connection is not None:
        connection.close()



