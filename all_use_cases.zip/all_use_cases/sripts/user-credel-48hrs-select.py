#!/usr/bin/env python
import psycopg2
import subprocess

connection = None
usernames = []
try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")
    cursor = connection.cursor()

    postgres_deleted_users_query = """select o.id,o.target_user_name,o.action,o.creation_time,o.nxt_creation_time,o.diff from
(
select id, target_user_name, action, creation_time, lead (creation_time,1) over (partition by target_user_name order by target_user_name, creation_time) as nxt_creation_time, EXTRACT (DAYS FROM (lead (creation_time,1) over (partition by target_user_name order by target_user_name, creation_time) - creation_time)) as diff from user_creation
) o
WHERE o.diff IN (0,1) AND o.action='create' AND o.nxt_creation_time BETWEEN COALESCE((SELECT MAX(script_timestamp) FROM run_log WHERE script_type='cre_del'),(now()::date - INTERVAL '48 hours')) AND now();"""

    cursor.execute(postgres_deleted_users_query)

    row = cursor.fetchone()
    print("Number of rows:", cursor.rowcount)

    while row is not None:
        #print(row[1])
        usernames.append(row[1])
        row = cursor.fetchone()

    cursor.close()

except (Exception, psycopg2.Error) as e:
    print("Error while fetching data from postgresql:",e)

finally:
    if connection is not None:
        connection.close()


for name in usernames:
    e = 'echo 1:postgres-get-deleted-users.py:UserCreatedDeleted48 {} | nc -Uu /var/ossec/queue/ossec/queue'.format(name)
    print(e)
    subprocess.call(e,shell=True)

print("Done")


postgres_runlog_insert_query = """ INSERT INTO run_log (script_type, script_timestamp) VALUES ('cre_del','now()')"""

postgres_delete_acc_change_query = """TRUNCATE TABLE user_creation"""

try:
    connection = psycopg2.connect(user="postgres",
                                  password="postgres",
                                  host="localhost",
                                  port="5432",
                                  database="wazuhdb")

    cursor = connection.cursor()

    try:
        cursor.execute(postgres_runlog_insert_query)
        cursor.execute(postgres_delete_acc_change_query)

    except psycopg2.Error as e:
        print('ERROR', e)
        connection.rollback()

    else:
        connection.commit()

    cursor.close()

except Exception as e:
    print ('ERROR', e)

finally:
    if connection is not None:
        connection.close()


